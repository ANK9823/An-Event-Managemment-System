package com.ems.eventmanagementsystem.controller;

import com.ems.eventmanagementsystem.dto.ResponseDto;
import com.ems.eventmanagementsystem.service.EventTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/ems")
public class EventTypeController {

    @Autowired
    EventTypeService eventTypeService;

    @GetMapping(value = "/geteventstype", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseDto getAllEventTypes() throws Exception {
        ResponseDto responseDto = new ResponseDto();
        responseDto.setResponseCode(HttpStatus.OK.toString());
        responseDto.setResponseMsg("SUCCESS");
        responseDto.setContent(eventTypeService.getAllEventTypes());
        return responseDto;
    }
}
