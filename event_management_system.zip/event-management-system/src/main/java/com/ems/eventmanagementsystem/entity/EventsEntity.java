package com.ems.eventmanagementsystem.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "Events", schema = "eventmanagement", catalog = "")
public class EventsEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "EventID", nullable = false)
    private Integer eventId;
    @Basic
    @Column(name = "EventTypeID", nullable = true)
    private Integer eventTypeId;
    @Basic
    @Column(name = "EventName", nullable = false, length = 100)
    private String eventName;
    @Basic
    @Column(name = "EventCreatedDate", nullable = false)
    private String eventCreatedDate;
    @Basic
    @Column(name = "EventLocation", nullable = true, length = 100)
    private String eventLocation;
    @Basic
    @Column(name = "PlannerID", nullable = true)
    private Integer plannerId;
    @Basic
    @Column(name = "description", nullable = true, length = -1)
    private String description;

    public Integer getEventId() {
        return eventId;
    }

    public void setEventId(Integer eventId) {
        this.eventId = eventId;
    }

    public Integer getEventTypeId() {
        return eventTypeId;
    }

    public void setEventTypeId(Integer eventTypeId) {
        this.eventTypeId = eventTypeId;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventCreatedDate() {
        return eventCreatedDate;
    }

    public void setEventCreatedDate(String eventCreatedDate) {
        this.eventCreatedDate = eventCreatedDate;
    }

    public String getEventLocation() {
        return eventLocation;
    }

    public void setEventLocation(String eventLocation) {
        this.eventLocation = eventLocation;
    }

    public Integer getPlannerId() {
        return plannerId;
    }

    public void setPlannerId(Integer plannerId) {
        this.plannerId = plannerId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EventsEntity that = (EventsEntity) o;
        return Objects.equals(eventId, that.eventId) && Objects.equals(eventTypeId, that.eventTypeId) && Objects.equals(eventName, that.eventName) && Objects.equals(eventCreatedDate, that.eventCreatedDate) && Objects.equals(eventLocation, that.eventLocation) && Objects.equals(plannerId, that.plannerId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(eventId, eventTypeId, eventName, eventCreatedDate, eventLocation, plannerId);
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
