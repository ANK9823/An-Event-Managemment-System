package com.ems.eventmanagementsystem.service.impl;

import com.ems.eventmanagementsystem.dto.EmailDto;
import com.ems.eventmanagementsystem.exception.CommonException;
import com.ems.eventmanagementsystem.service.EventService;
import com.ems.eventmanagementsystem.service.MailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class MailServiceImpl implements MailService {


    @Value("${spring.mail.username}")
    private String sender;

    @Autowired
    private JavaMailSender emailSender;

    @Override
    public void SendMail(EmailDto entity) throws Exception{
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(sender);
            message.setTo(entity.getReceiver());
            message.setSubject(entity.getSubject());
            message.setText(entity.getBody());
            emailSender.send(message);
        } catch (Exception e) {
            throw new CommonException("Failed to send mail");
        }
    }
}
