package com.ems.eventmanagementsystem.controller;

import com.ems.eventmanagementsystem.dto.ResponseDto;
import com.ems.eventmanagementsystem.entity.EventsEntity;
import com.ems.eventmanagementsystem.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/ems")
public class EventsController {

    @Autowired
    EventService eventService;

    @PostMapping(value = "/createnewevent", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseDto CreateNewEvent(@RequestBody EventsEntity entity) throws Exception {

        ResponseDto responseDto = new ResponseDto();
        responseDto.setResponseCode(HttpStatus.OK.toString());
        responseDto.setResponseMsg("EVENT_CREATED");
        responseDto.setContent(eventService.CreateNewEvent(entity));
        return responseDto;

    }

    @GetMapping(value = "/getallevents/{eventTypeId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseDto getAllEvents(@PathVariable("eventTypeId") int eventTypeId) throws Exception {
        ResponseDto responseDto = new ResponseDto();
        responseDto.setResponseCode(HttpStatus.OK.toString());
        responseDto.setResponseMsg("SUCCESS");
        responseDto.setContent(eventService.getAll(eventTypeId));
        return responseDto;
    }

    @GetMapping(value = "/getallevent/{eventId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseDto Getallevent(@PathVariable("eventId") int eventId) throws Exception {

        ResponseDto responseDto = new ResponseDto();
        responseDto.setResponseCode(HttpStatus.OK.toString());
        responseDto.setResponseMsg("SUCCESS");
        responseDto.setContent(eventService.GetEventByID(eventId));
        return responseDto;

    }

    @GetMapping(value = "/getRecommendedevents/{eventTypeId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseDto getRecommendedEvents(@PathVariable("eventTypeId") int eventTypeId) throws Exception {

        ResponseDto responseDto = new ResponseDto();
        responseDto.setResponseCode(HttpStatus.OK.toString());
        responseDto.setResponseMsg("SUCCESS");
        responseDto.setContent(eventService.getRecommendedEvents(eventTypeId));
        return responseDto;

    }

    @GetMapping(value = "/getAllEventByPlannerId/{plannerId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseDto GetAllEventByPlannerId(@PathVariable("plannerId") int plannerId) throws Exception {

        ResponseDto responseDto = new ResponseDto();
        responseDto.setResponseCode(HttpStatus.OK.toString());
        responseDto.setResponseMsg("SUCCESS");
        responseDto.setContent(eventService.GetAllEventByPlannerId(plannerId));
        return responseDto;

    }

    @DeleteMapping(value = "/deleteEvent/{eventId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseDto DeleteEventByEventId(@PathVariable("eventId") int eventId) throws Exception {

        eventService.DeleteEventByEventId(eventId);
        ResponseDto responseDto = new ResponseDto();
        responseDto.setResponseCode(HttpStatus.OK.toString());
        responseDto.setResponseMsg("SUCCESS");
        responseDto.setContent(null);
        return responseDto;

    }

    @PutMapping(value = "/updateEvent/{eventId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseDto UpdateEventByEventID(@RequestBody EventsEntity entity, @PathVariable("eventId") int userId) {
        eventService.UpdateEventByEventID(entity, userId);
        ResponseDto responseDto = new ResponseDto();
        responseDto.setResponseCode(HttpStatus.OK.toString());
        responseDto.setResponseMsg("SUCCESS");
        responseDto.setContent(null);
        return responseDto;

    }



}
