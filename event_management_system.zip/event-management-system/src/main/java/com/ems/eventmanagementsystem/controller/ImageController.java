package com.ems.eventmanagementsystem.controller;

import com.ems.eventmanagementsystem.dto.ResponseDto;
import com.ems.eventmanagementsystem.service.ImageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/v1/ems")
public class ImageController {

    @Autowired
    ImageService imageService;

    @PostMapping(value = "/uploadImages")
    public ResponseDto UploadImage(
            @RequestParam("images") MultipartFile[] files,
            @RequestParam("userId") int userId,
            @RequestParam("eventId") int eventId) throws Exception {
        imageService.UploadImage(files, userId, eventId);
        ResponseDto responseDto = new ResponseDto();
        responseDto.setResponseCode(HttpStatus.OK.toString());
        responseDto.setResponseMsg("SUCCESS");
        responseDto.setContent(null);
        return responseDto;
    }

    @GetMapping(value = "/getByPlannerAndEvent/{plannerId}/{eventId}", produces = MediaType.APPLICATION_JSON_VALUE )
    public ResponseDto getImagesByPlannerAndEvent(
            @PathVariable("plannerId") int plannerId,
            @PathVariable("eventId") int eventId) throws Exception {
        ResponseDto responseDto = new ResponseDto();
        responseDto.setResponseCode(HttpStatus.OK.toString());
        responseDto.setResponseMsg("SUCCESS");
        responseDto.setContent(imageService.findByPlannerIdAndEventId(plannerId,eventId));
        return responseDto;
    }

}
