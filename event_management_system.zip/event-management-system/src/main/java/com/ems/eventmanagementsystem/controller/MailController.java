package com.ems.eventmanagementsystem.controller;

import com.ems.eventmanagementsystem.dto.EmailDto;
import com.ems.eventmanagementsystem.dto.ResponseDto;
import com.ems.eventmanagementsystem.service.MailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/ems")
public class MailController {

    @Autowired
    MailService mailService;

    @PostMapping(value = "/sendmail", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseDto SendMail(@RequestBody EmailDto entity) throws Exception{

        mailService.SendMail(entity);

        ResponseDto responseDto = new ResponseDto();
        responseDto.setResponseCode(HttpStatus.OK.toString());
        responseDto.setResponseMsg("SENT");
        responseDto.setContent(null);
        return responseDto;

    }

}
