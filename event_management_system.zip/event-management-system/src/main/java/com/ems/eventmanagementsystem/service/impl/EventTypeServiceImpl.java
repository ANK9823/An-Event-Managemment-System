package com.ems.eventmanagementsystem.service.impl;

import com.ems.eventmanagementsystem.entity.EventTypesEntity;
import com.ems.eventmanagementsystem.repo.EventTypeRepo;
import com.ems.eventmanagementsystem.service.EventTypeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EventTypeServiceImpl implements EventTypeService {

    @Autowired
    EventTypeRepo eventTypeRepo;

    @Override
    public List<EventTypesEntity> getAllEventTypes() {
        return eventTypeRepo.findAll();
    }
}
