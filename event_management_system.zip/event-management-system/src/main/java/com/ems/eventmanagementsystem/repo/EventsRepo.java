package com.ems.eventmanagementsystem.repo;

import com.ems.eventmanagementsystem.dto.EventDto;
import com.ems.eventmanagementsystem.entity.EventsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EventsRepo extends JpaRepository<EventsEntity, Integer> {

    @Query("select new com.ems.eventmanagementsystem.dto.EventDto(e,ee.eventType,u.username)" +
            " from EventsEntity e inner join UsersEntity u on e.plannerId = u.userId inner join EventTypesEntity ee on e.eventTypeId = ee.eventTypeId where e.eventTypeId=:eventTypeId")
    List<EventDto> getAllData(int eventTypeId);

    Optional<EventsEntity> getEventsEntitiesByEventId(int id);


    @Query("select new com.ems.eventmanagementsystem.dto.EventDto(e,u.eventType)" +
            " from EventsEntity e inner join EventTypesEntity u on e.eventTypeId = u.eventTypeId where e.plannerId=:plannerId")
    List<EventDto> getAllDataByPlannerId(int plannerId);

    int deleteByEventId(int eventId);

}
