package com.ems.eventmanagementsystem.service;

import com.ems.eventmanagementsystem.dto.LoginReq;
import com.ems.eventmanagementsystem.dto.LoginRes;
import com.ems.eventmanagementsystem.entity.UsersEntity;

import java.security.NoSuchAlgorithmException;

public interface UserService {
    void CreateUser(UsersEntity entity) throws NoSuchAlgorithmException;

    LoginRes LoginUser(LoginReq entity) throws NoSuchAlgorithmException;

    UsersEntity GetUserData(int userId);

    void UpdateUser(UsersEntity entity, int userId);
}
