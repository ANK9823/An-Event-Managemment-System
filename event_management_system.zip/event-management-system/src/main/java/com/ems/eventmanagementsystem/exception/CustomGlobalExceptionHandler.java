package com.ems.eventmanagementsystem.exception;

import com.ems.eventmanagementsystem.dto.ResponseDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class CustomGlobalExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(NoDataFoundException.class)
    public ResponseEntity<ResponseDto> customHandleNoDataFoundException(Exception ex, WebRequest request) {

        ResponseDto errorResponse = new ResponseDto();
        errorResponse.setResponseCode("501");
        errorResponse.setResponseMsg("NO_DATA_FOUND");
        errorResponse.setContent(null);

        return new ResponseEntity<>(errorResponse, HttpStatus.OK);

    }

    @ExceptionHandler(CommonException.class)
    public ResponseEntity<ResponseDto> customHandleCommonException(Exception ex, WebRequest request) {

        ResponseDto errorResponse = new ResponseDto();
        errorResponse.setResponseCode("500");
        errorResponse.setResponseMsg(ex.getMessage());
        errorResponse.setContent(null);

        return new ResponseEntity<>(errorResponse, HttpStatus.OK);

    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ResponseDto> customHandleException(Exception ex, WebRequest request) {

        ResponseDto errorResponse = new ResponseDto();
        errorResponse.setResponseCode("500");
        errorResponse.setResponseMsg(ex.getMessage());
        errorResponse.setContent(null);

        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);

    }

}
