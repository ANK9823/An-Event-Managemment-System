package com.ems.eventmanagementsystem.service.impl;

import com.ems.eventmanagementsystem.dto.TopEventsDto;
import com.ems.eventmanagementsystem.dto.UserReviewsDto;
import com.ems.eventmanagementsystem.entity.UserReviewsEntity;
import com.ems.eventmanagementsystem.repo.UserReviewRepo;
import com.ems.eventmanagementsystem.service.UserReviewsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsersReviewsServiceImpl implements UserReviewsService {

    @Autowired
    UserReviewRepo userReviewRepo;

    @Override
    public void addReview(UserReviewsEntity entity) throws Exception {
        userReviewRepo.save(entity);
    }

    @Override
    public List<UserReviewsEntity> getAllReviews() throws Exception {
        return userReviewRepo.findAll();
    }

    @Override
    public List<UserReviewsDto> getReviewByEvent(int eventId) throws Exception {
        return userReviewRepo.fetchUserReviewsEntitiesByEventId(eventId);
    }

    @Override
    public List<TopEventsDto> getTopReviewsEvents() throws Exception {
        return userReviewRepo.fetchUserEventsOfTopReviews();
    }
}
