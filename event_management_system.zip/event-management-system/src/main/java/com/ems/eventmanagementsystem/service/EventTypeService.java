package com.ems.eventmanagementsystem.service;

import com.ems.eventmanagementsystem.entity.EventTypesEntity;

import java.util.List;

public interface EventTypeService {
    List<EventTypesEntity> getAllEventTypes();
}
