package com.ems.eventmanagementsystem.service.impl;

import com.ems.eventmanagementsystem.dto.LoginReq;
import com.ems.eventmanagementsystem.dto.LoginRes;
import com.ems.eventmanagementsystem.entity.UsersEntity;
import com.ems.eventmanagementsystem.exception.CommonException;
import com.ems.eventmanagementsystem.exception.NoDataFoundException;
import com.ems.eventmanagementsystem.repo.UsersRepo;
import com.ems.eventmanagementsystem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UsersRepo usersRepo;

    @Override
    public void CreateUser(UsersEntity entity) throws NoSuchAlgorithmException {

        if (usersRepo.countByEmail(entity.getEmail()) != 0) {
            throw new CommonException("User exist");
        }
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] messageDigest = md.digest(entity.getPassword().getBytes());
        StringBuilder hexString = new StringBuilder();

        for (byte b : messageDigest) {
            hexString.append(String.format("%02x", b));
        }
        entity.setPassword(String.valueOf(hexString));
        usersRepo.save(entity);

    }

    @Override
    public LoginRes LoginUser(LoginReq entity) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] messageDigest = md.digest(entity.getPassword().getBytes());
        StringBuilder hexString = new StringBuilder();

        for (byte b : messageDigest) {
            hexString.append(String.format("%02x", b));
        }
        entity.setPassword(String.valueOf(hexString));
        UsersEntity e = usersRepo.getUsersEntityByPasswordAndEmail(entity.getPassword(), entity.getEmail()).orElse(new UsersEntity());
        if (null == e.getUserId()) {
            throw new NoDataFoundException("User not found");
        }
        return new LoginRes(e.getUserId(), e.getUsername(), e.getRoleId());
    }

    @Override
    public UsersEntity GetUserData(int userId) {
        return usersRepo.getUsersEntityByUserId(userId).orElse(new UsersEntity());
    }

    @Override
    public void UpdateUser(UsersEntity entity, int userId) {
        UsersEntity usersEntity = usersRepo.getUsersEntityByUserId(userId).orElse(new UsersEntity());

        if (entity.getPassword() != null) {
            usersEntity.setPassword(entity.getPassword());
        }
        if (entity.getEmail() != null) {
            usersEntity.setEmail(entity.getEmail());
        }
        if (entity.getPhone() != null) {
            usersEntity.setPhone(entity.getPhone());
        }
        if (entity.getRoleId() != null) {
            usersEntity.setRoleId(entity.getRoleId());
        }

        usersRepo.save(usersEntity);
    }
}
