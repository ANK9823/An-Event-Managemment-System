package com.ems.eventmanagementsystem.dto;

import com.ems.eventmanagementsystem.entity.UserReviewsEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
public class UserReviewsDto {
    private UserReviewsEntity entity;
    private String clientName;
}
