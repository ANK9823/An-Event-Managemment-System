package com.ems.eventmanagementsystem.entity;

import javax.persistence.*;
import java.util.Arrays;
import java.util.Objects;

@Entity
@Table(name = "Images", schema = "eventmanagement", catalog = "")
public class ImagesEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ImageID", nullable = false)
    private Integer imageId;
    @Basic
    @Column(name = "EventID", nullable = false)
    private Integer eventId;
    @Basic
    @Column(name = "PlannerID", nullable = false, length = 255)
    private Integer plannerId;
    @Lob
    @Basic
    @Column(name = "Image", nullable = true)
    private byte[] image;

    public Integer getImageId() {
        return imageId;
    }

    public void setImageId(Integer imageId) {
        this.imageId = imageId;
    }

    public Integer getEventId() {
        return eventId;
    }

    public void setEventId(Integer eventId) {
        this.eventId = eventId;
    }

    public Integer getPlannerId() {
        return plannerId;
    }

    public void setPlannerId(Integer plannerId) {
        this.plannerId = plannerId;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ImagesEntity that = (ImagesEntity) o;
        return Objects.equals(imageId, that.imageId) && Objects.equals(eventId, that.eventId) && Objects.equals(plannerId, that.plannerId) && Arrays.equals(image, that.image);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(imageId, eventId, plannerId);
        result = 31 * result + Arrays.hashCode(image);
        return result;
    }
}
