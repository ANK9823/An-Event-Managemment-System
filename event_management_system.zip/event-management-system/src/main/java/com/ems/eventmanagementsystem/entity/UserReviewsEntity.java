package com.ems.eventmanagementsystem.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "UserReviews", schema = "eventmanagement", catalog = "")
public class UserReviewsEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "ReviewID", nullable = false)
    private Integer reviewId;
    @Basic
    @Column(name = "EventID", nullable = true)
    private Integer eventId;
    @Basic
    @Column(name = "ClientID", nullable = true)
    private Integer clientId;
    @Basic
    @Column(name = "Rating", nullable = true)
    private Integer rating;
    @Basic
    @Column(name = "ReviewText", nullable = true, length = -1)
    private String reviewText;

    public Integer getReviewId() {
        return reviewId;
    }

    public void setReviewId(Integer reviewId) {
        this.reviewId = reviewId;
    }

    public Integer getEventId() {
        return eventId;
    }

    public void setEventId(Integer eventId) {
        this.eventId = eventId;
    }

    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public Integer getRating() {
        return rating;
    }

    public void setRating(Integer rating) {
        this.rating = rating;
    }

    public String getReviewText() {
        return reviewText;
    }

    public void setReviewText(String reviewText) {
        this.reviewText = reviewText;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        UserReviewsEntity that = (UserReviewsEntity) o;
        return Objects.equals(reviewId, that.reviewId) && Objects.equals(eventId, that.eventId) && Objects.equals(clientId, that.clientId) && Objects.equals(rating, that.rating) && Objects.equals(reviewText, that.reviewText);
    }

    @Override
    public int hashCode() {
        return Objects.hash(reviewId, eventId, clientId, rating, reviewText);
    }
}
