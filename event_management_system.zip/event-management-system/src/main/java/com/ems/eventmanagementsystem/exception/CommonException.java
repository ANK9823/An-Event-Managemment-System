package com.ems.eventmanagementsystem.exception;

public class CommonException extends RuntimeException {
    public CommonException(String message) {
        super(message);
    }
}
