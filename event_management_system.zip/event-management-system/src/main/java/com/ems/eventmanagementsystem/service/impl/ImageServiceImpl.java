package com.ems.eventmanagementsystem.service.impl;

import com.ems.eventmanagementsystem.dto.ImageDto;
import com.ems.eventmanagementsystem.entity.ImagesEntity;
import com.ems.eventmanagementsystem.exception.CommonException;
import com.ems.eventmanagementsystem.repo.ImageRepo;
import com.ems.eventmanagementsystem.service.ImageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@Service
@Transactional
public class ImageServiceImpl implements ImageService {

    @Autowired
    ImageRepo imageRepo;

    @Override
    public void UploadImage(MultipartFile[] files, int userId, int eventId) throws Exception {
        try {
            for (MultipartFile file : files) {
                ImagesEntity image = new ImagesEntity();
                image.setImage(file.getBytes());
                image.setPlannerId(userId);
                image.setEventId(eventId);
                imageRepo.save(image);
            }

        } catch (Exception e) {
            e.printStackTrace();
            throw new CommonException("Failed to upload images");
        }
    }

    @Override
    public List<ImageDto> findByPlannerIdAndEventId(int plannerId, int eventId) throws Exception {

        List<ImageDto> list = new ArrayList<>();
        List<ImagesEntity> entities = imageRepo.fetchByEventId(eventId);
        entities.forEach(imagesEntity -> {
            list.add(new ImageDto(Base64.getEncoder().encodeToString(imagesEntity.getImage())));
        });
        return list;
    }

}
