package com.ems.eventmanagementsystem.service;

import com.ems.eventmanagementsystem.dto.ImageDto;
import com.ems.eventmanagementsystem.entity.ImagesEntity;
import org.springframework.web.multipart.MultipartFile;

import java.util.Base64;
import java.util.List;

public interface ImageService {
    void UploadImage(MultipartFile[] files, int userId, int eventId) throws Exception;

    List<ImageDto> findByPlannerIdAndEventId(int plannerId, int eventId) throws Exception;
}
