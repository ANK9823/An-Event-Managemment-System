package com.ems.eventmanagementsystem.controller;

import com.ems.eventmanagementsystem.dto.ResponseDto;
import com.ems.eventmanagementsystem.entity.UserReviewsEntity;
import com.ems.eventmanagementsystem.service.UserReviewsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/ems")
public class UserReviewsController {

    @Autowired
    UserReviewsService userReviewsService;

    @PostMapping(value = "/addreview", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseDto addReview(@RequestBody UserReviewsEntity entity) throws Exception{

        userReviewsService.addReview(entity);

        ResponseDto responseDto = new ResponseDto();
        responseDto.setResponseCode(HttpStatus.OK.toString());
        responseDto.setResponseMsg("USER_REVIEW_ADDED");
        responseDto.setContent(null);
        return responseDto;

    }

    @GetMapping(value = "/getallreview", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseDto getAllReviews() throws Exception {
        ResponseDto responseDto = new ResponseDto();
        responseDto.setResponseCode(HttpStatus.OK.toString());
        responseDto.setResponseMsg("SUCCESS");
        responseDto.setContent(userReviewsService.getAllReviews());
        return responseDto;
    }

    @GetMapping(value = "/getreviewbyevent/{eventId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseDto getReviewByEvent(@PathVariable("eventId") int eventId) throws Exception {
        ResponseDto responseDto = new ResponseDto();
        responseDto.setResponseCode(HttpStatus.OK.toString());
        responseDto.setResponseMsg("SUCCESS");
        responseDto.setContent(userReviewsService.getReviewByEvent(eventId));
        return responseDto;
    }

}
