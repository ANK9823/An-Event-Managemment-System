package com.ems.eventmanagementsystem.repo;

import com.ems.eventmanagementsystem.dto.TopEventsDto;
import com.ems.eventmanagementsystem.dto.UserReviewsDto;
import com.ems.eventmanagementsystem.entity.UserReviewsEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UserReviewRepo extends JpaRepository<UserReviewsEntity, Integer> {

    @Query("select new com.ems.eventmanagementsystem.dto.UserReviewsDto(ur,u.username) from UserReviewsEntity ur, UsersEntity u where u.userId = ur.clientId and ur.eventId=:eid")
    List<UserReviewsDto> fetchUserReviewsEntitiesByEventId(@Param("eid") int eid);

    @Query("select new com.ems.eventmanagementsystem.dto.TopEventsDto(e.eventId,count(e)) from UserReviewsEntity e where e.rating > 4 group by e.eventId")
    List<TopEventsDto> fetchUserEventsOfTopReviews();

}
