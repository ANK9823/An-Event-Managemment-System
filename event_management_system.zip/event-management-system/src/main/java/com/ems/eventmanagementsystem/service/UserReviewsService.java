package com.ems.eventmanagementsystem.service;

import com.ems.eventmanagementsystem.dto.TopEventsDto;
import com.ems.eventmanagementsystem.dto.UserReviewsDto;
import com.ems.eventmanagementsystem.entity.UserReviewsEntity;

import java.util.List;

public interface UserReviewsService {
    void addReview(UserReviewsEntity entity) throws Exception;

    List<UserReviewsEntity> getAllReviews()throws Exception;

    List<UserReviewsDto> getReviewByEvent(int eventId)throws Exception;

    List<TopEventsDto> getTopReviewsEvents()throws Exception;
}
