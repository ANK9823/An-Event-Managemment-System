package com.ems.eventmanagementsystem.service.impl;

import com.ems.eventmanagementsystem.dto.EventDto;
import com.ems.eventmanagementsystem.dto.TopEventsDto;
import com.ems.eventmanagementsystem.entity.EventsEntity;
import com.ems.eventmanagementsystem.entity.ImagesEntity;
import com.ems.eventmanagementsystem.entity.UsersEntity;
import com.ems.eventmanagementsystem.exception.CommonException;
import com.ems.eventmanagementsystem.repo.EventsRepo;
import com.ems.eventmanagementsystem.repo.ImageRepo;
import com.ems.eventmanagementsystem.repo.UsersRepo;
import com.ems.eventmanagementsystem.service.EventService;
import com.ems.eventmanagementsystem.service.UserReviewsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

@Service
public class EventServiceImpl implements EventService {

    @Autowired
    EventsRepo eventsRepo;

    @Autowired
    UserReviewsService userReviewsService;

    @Autowired
    UsersRepo usersRepo;

    @Autowired
    ImageRepo imageRepo;

    @Override
    public Integer CreateNewEvent(EventsEntity entity) throws Exception {
        LocalDate currentDate = LocalDate.now();
        entity.setEventCreatedDate(currentDate.toString());
        EventsEntity savedEvent = eventsRepo.save(entity);
        return savedEvent.getEventId();
    }

    @Override
    public List<EventDto> getAll(int eventTypeId) throws Exception {

        List<EventDto> allData = eventsRepo.getAllData(eventTypeId);
        List<EventDto> dataList = new ArrayList<>();

        allData.forEach(eventDto -> {
            List<ImagesEntity> e = imageRepo.fetchByEventId(eventDto.getEntity().getEventId());
            List<String> images = new ArrayList<>();
            e.forEach(imagesEntity -> {
                images.add(Base64.getEncoder().encodeToString(imagesEntity.getImage()));
            });
            eventDto.setImages(images);
            dataList.add(eventDto);
        });
        return dataList;
    }

    @Override
    public EventsEntity GetEventByID(int eventId) throws Exception {
        return eventsRepo.getEventsEntitiesByEventId(eventId).orElse(null);
    }

    @Override
    public List<EventDto> getRecommendedEvents(int eventTypeId) throws Exception {

        List<EventDto> list = new ArrayList<>();

        List<TopEventsDto> topReviewsEvents = userReviewsService.getTopReviewsEvents();
        for (TopEventsDto e : topReviewsEvents) {
            EventsEntity eventsEntity = GetEventByID(e.getEventId());
            if (eventsEntity.getEventTypeId() == eventTypeId) {
                List<ImagesEntity> em = imageRepo.fetchByEventId(eventsEntity.getEventId());
                List<String> images = new ArrayList<>();
                em.forEach(imagesEntity -> {
                    images.add(Base64.getEncoder().encodeToString(imagesEntity.getImage()));
                });
                EventDto eventDto = new EventDto();
                eventDto.setEntity(eventsEntity);
                eventDto.setImages(images);
                UsersEntity usersEntityByUserId = usersRepo.getUsersEntityByUserId(eventsEntity.getPlannerId()).orElse(new UsersEntity());
                eventDto.setPlannerName(usersEntityByUserId.getUsername());
                list.add(eventDto);
            }
        }

        return list;
    }

    @Override
    public List<EventDto> GetAllEventByPlannerId(int plannerId) throws Exception {
        List<EventDto> allDataByPlannerId = eventsRepo.getAllDataByPlannerId(plannerId);
        List<EventDto> dataList = new ArrayList<>();

        allDataByPlannerId.forEach(eventDto -> {
            List<ImagesEntity> e = imageRepo.fetchByEventId(eventDto.getEntity().getEventId());
            List<String> images = new ArrayList<>();
            e.forEach(imagesEntity -> {
                images.add(Base64.getEncoder().encodeToString(imagesEntity.getImage()));
            });
            eventDto.setImages(images);
            dataList.add(eventDto);
        });
        return dataList;
    }

    @Override
    @Transactional
    public void DeleteEventByEventId(int eventId) throws Exception {

        imageRepo.deleteAllByEventId(eventId);

        int b = eventsRepo.deleteByEventId(eventId);
        if (b == 0) {
            throw new CommonException("failed to delete");
        }

    }

    @Override
    public void UpdateEventByEventID(EventsEntity entity, int userId) {
        LocalDate currentDate = LocalDate.now();
        entity.setEventCreatedDate(currentDate.toString());
        eventsRepo.save(entity);
    }
}
