package com.ems.eventmanagementsystem.service;

import com.ems.eventmanagementsystem.dto.EventDto;
import com.ems.eventmanagementsystem.entity.EventsEntity;

import java.util.List;

public interface EventService {
    Integer CreateNewEvent(EventsEntity entity) throws Exception;

    List<EventDto> getAll(int eventTypeId) throws Exception;

    EventsEntity GetEventByID(int eventId)throws Exception;

    List<EventDto> getRecommendedEvents(int eventTypeId)throws Exception;

    List<EventDto> GetAllEventByPlannerId(int plannerId) throws Exception;

    void DeleteEventByEventId(int eventId) throws Exception;

    void UpdateEventByEventID(EventsEntity entity, int userId);
}
