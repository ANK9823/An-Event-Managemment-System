package com.ems.eventmanagementsystem.dto;

import com.ems.eventmanagementsystem.entity.EventsEntity;
import com.ems.eventmanagementsystem.entity.ImagesEntity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Base64;
import java.util.List;


@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
public class EventDto {
    private EventsEntity entity;
    private String eventType;

    public EventDto(EventsEntity entity, String eventType) {
        this.entity = entity;
        this.eventType = eventType;
    }

    public EventDto(EventsEntity entity, String eventType, String plannerName) {
        this.entity = entity;
        this.eventType = eventType;
        this.plannerName = plannerName;
    }

    private String plannerName;
    private List<String> images;
}
