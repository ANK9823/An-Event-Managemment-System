package com.ems.eventmanagementsystem.entity;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "EventTypes", schema = "eventmanagement", catalog = "")
public class EventTypesEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "EventTypeID", nullable = false)
    private Integer eventTypeId;
    @Basic
    @Column(name = "EventType", nullable = false, length = 50)
    private String eventType;

    public Integer getEventTypeId() {
        return eventTypeId;
    }

    public void setEventTypeId(Integer eventTypeId) {
        this.eventTypeId = eventTypeId;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EventTypesEntity that = (EventTypesEntity) o;
        return Objects.equals(eventTypeId, that.eventTypeId) && Objects.equals(eventType, that.eventType);
    }

    @Override
    public int hashCode() {
        return Objects.hash(eventTypeId, eventType);
    }
}
