package com.ems.eventmanagementsystem.controller;

import com.ems.eventmanagementsystem.dto.LoginReq;
import com.ems.eventmanagementsystem.dto.ResponseDto;
import com.ems.eventmanagementsystem.entity.UsersEntity;
import com.ems.eventmanagementsystem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.security.NoSuchAlgorithmException;

@RestController
@RequestMapping("/v1/ems")
public class UsersController {

    @Autowired
    UserService userService;

    @PostMapping(value = "/signup", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseDto SignUp(@RequestBody UsersEntity entity) throws NoSuchAlgorithmException {

        userService.CreateUser(entity);

        ResponseDto responseDto = new ResponseDto();
        responseDto.setResponseCode(HttpStatus.OK.toString());
        responseDto.setResponseMsg("ACCOUNT_CREATED");
        responseDto.setContent(null);
        return responseDto;

    }

    @PostMapping(value = "/login", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseDto login(@RequestBody LoginReq entity) throws NoSuchAlgorithmException {

        ResponseDto responseDto = new ResponseDto();
        responseDto.setResponseCode(HttpStatus.OK.toString());
        responseDto.setResponseMsg("USER_AUTHENTICATED");
        responseDto.setContent(userService.LoginUser(entity));
        return responseDto;

    }

    @GetMapping(value = "/getuserdata/{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseDto GetUserData(@PathVariable("userId") int userId) {

        ResponseDto responseDto = new ResponseDto();
        responseDto.setResponseCode(HttpStatus.OK.toString());
        responseDto.setResponseMsg("SUCCESS");
        responseDto.setContent(userService.GetUserData(userId));
        return responseDto;

    }

    @PutMapping(value = "/UpdateUser/{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseDto UpdateUserByID(@RequestBody UsersEntity entity, @PathVariable("userId") int userId) {
        userService.UpdateUser(entity, userId);
        ResponseDto responseDto = new ResponseDto();
        responseDto.setResponseCode(HttpStatus.OK.toString());
        responseDto.setResponseMsg("SUCCESS");
        responseDto.setContent(null);
        return responseDto;

    }

}
