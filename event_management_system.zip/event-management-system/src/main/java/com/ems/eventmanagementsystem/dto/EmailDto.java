package com.ems.eventmanagementsystem.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
public class EmailDto {
    private String receiver;
    private String subject = "Event Management System";
    private String body;
}
