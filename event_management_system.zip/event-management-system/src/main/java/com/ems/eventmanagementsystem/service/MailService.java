package com.ems.eventmanagementsystem.service;

import com.ems.eventmanagementsystem.dto.EmailDto;

public interface MailService {
    void SendMail(EmailDto entity) throws Exception;
}
