import logo from './logo.svg';
import './App.css';
import Login from "./components/Login";
import {BrowserRouter, Route, Routes} from 'react-router-dom';
import Home from "./components/Home";
import SignUp from "./components/SignUp";
import {ToastContainer} from "react-toastify";
import Events from "./components/Events";
import PlanerEvent from "./components/PlannerEvents";
import NewEvents from "./components/NewEvent";
import BookAnEvents from "./components/BookAnEvent";
import ViewReviews from "./components/ViewReviews";
import NewReview from "./components/NewReview";
import RecommendedEvents from "./components/RecomendedEvents";
import DeleteEvent from "./components/DeleteEvent";
import EventUpdate from "./components/UpdateEvent";
import Index from "./components/Index";
export const API_URL = "http://localhost:8086"

function App() {
    return (
        <div className="App">
            <ToastContainer></ToastContainer>
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<Index/>}></Route>
                    <Route path="/home" element={<Home/>}></Route>
                    <Route path="/login" element={<Login/>}></Route>
                    <Route path="/signUp/:id" element={<SignUp/>}></Route>
                    <Route path="/events/:id" element={<Events/>}></Route>
                    <Route path="/planerEvent" element={<PlanerEvent/>}></Route>
                    <Route path="/newEvents" element={<NewEvents/>}></Route>
                    <Route path="/bookAnEvent/:id/:name/:plannerId" element={<BookAnEvents/>}></Route>
                    <Route path="/viewReviews/:id" element={<ViewReviews/>}></Route>
                    <Route path="/addReview/:eventId/:eventTypeId" element={<NewReview/>}></Route>
                    <Route path="/recommendedEvents/:eventTypeId" element={<RecommendedEvents/>}></Route>
                    <Route path="/deleteEvent/:id" element={<DeleteEvent/>}></Route>
                    <Route path="/updateEvent/:id" element={<EventUpdate/>}></Route>
                </Routes>
            </BrowserRouter>
        </div>
    );
}

export default App;
