import {Link, useNavigate, useParams} from "react-router-dom";
import {useEffect, useState} from "react";
import {toast} from "react-toastify";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Header from "./Header";
import {API_URL} from "../App";


const RecommendedEvents = () => {

    const navigate = useNavigate()
    const [records, setRecords] = useState([]);
    const {eventTypeId} = useParams();


    const sliderSettings = {
        dots: true, // Show dots for navigation
        infinite: true, // Infinite loop
        speed: 500, // Transition speed
        slidesToShow: 1, // Number of slides to show at a time
        slidesToScroll: 1, // Number of slides to scroll
    };

    useEffect(() => {

        fetch(API_URL + "/v1/ems/getRecommendedevents/" + eventTypeId, {
                method: "GET"
            }
        ).then((res) => {
            return res.json();
        }).then((resp) => {
            setRecords(resp.content)
        }).catch((err) => {
            toast.error('Failed to get data :' + err.message);
        });
    }, [])

    function handleGoogleSearch(val) {
        // const query = val;
        // console.log(val)
        // const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
        // window.open(searchUrl, '_blank');
    }

    return (
        <div className="row">
            <Header/>
            {
                records.length === 0 ? (
                        <div className="no-data-found">No data found</div>
                    ) : (
                    records.map((record, index) => (
                <div key={index} className="card text-center offset-lg-2 col-lg-8" style={{marginTop: "10px"}}>
                    <div className="card-header">posted by {record.plannerName}</div>
                    <div className="card-body">
                        <h5 className="card-title">{record.entity.eventName}</h5>
                        <p className="card-text" style={{color: "gray"}}>
                            {record.entity.description}
                        </p>
                        <div>
                            <Slider {...sliderSettings}>
                                {record.images.map((image, imageIndex) => (
                                    <div key={imageIndex} className="align-content-center">
                                        <img
                                            src={`data:image/png;base64,${image}`}
                                            width="500"
                                            alt="Image"
                                            style={{
                                                display: "block",
                                                margin: "0 auto",
                                            }}
                                        />
                                    </div>
                                ))}
                            </Slider>
                        </div>
                        <b/>
                        <div style={{marginTop: "30px"}}>
                            <p>
                                Location -{" "}
                                <a onClick={() => handleGoogleSearch(record.entity.eventLocation)}>
                                    {record.entity.eventLocation}
                                </a>
                            </p>
                            <a
                                href={`/bookAnEvent/${record.entity.eventId}/${record.entity.eventName}/${record.entity.plannerId}`}
                                className="btn btn-primary"
                            >
                                Book now
                            </a>
                        </div>
                    </div>
                    <div className="card-footer text-muted">
                        posted on : {record.entity.eventCreatedDate}
                    </div>
                </div>
            )))}
        </div>
    )

}

export default RecommendedEvents;
