import {useNavigate, useParams} from "react-router-dom";
import {useEffect, useState} from "react";
import {toast} from "react-toastify";
import Header from "./Header";
import {API_URL} from "../App";


const ViewReviews = () => {

    const navigate = useNavigate()
    const [records, setRecords] = useState([]);
    const {id} = useParams();

    useEffect(() => {

        fetch(API_URL + "/v1/ems/getreviewbyevent/" + id, {
                method: "GET"
            }
        ).then((res) => {
            return res.json();
        }).then((resp) => {
            setRecords(resp.content)
            if (records.length == 0) {

            }
        }).catch((err) => {
            toast.error('Failed to get data :' + err.message);
        });
    }, [])

    return (
        <div>
            <Header/>
            <div className="row">
                {records.length === 0 ? (
                    <div className="no-data-found">No data found</div>
                ) : (records.map((list, index) => (
                    <div className="card text-center offset-lg-2 col-lg-8" style={{marginTop: '10px'}}>
                        <div className="card-header">
                            {list.clientName}
                        </div>
                        <div className="card-body">
                            <h5 className="card-title">Ratings : {list.entity.rating} </h5>
                            <p className="card-text" style={{color: 'gray'}}>{list.entity.reviewText} </p>
                        </div>
                    </div>
                )))}
            </div>
        </div>
    )

}

export default ViewReviews;
