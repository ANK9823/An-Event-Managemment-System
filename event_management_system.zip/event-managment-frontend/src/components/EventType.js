import {useEffect, useState} from "react";
import {toast} from "react-toastify";
import {useNavigate} from "react-router-dom";
import '../App.css'
import {API_URL} from "../App";

const EventsType = () => {
    const navigate = useNavigate()
    const [eventsType, setEventsType] = useState([]);
    const [selectedOption, setSelectedOption] = useState("");
    const handleChange = (event) => {
        navigate("/events/" + event.target.value)
    };

    useEffect(() => {
        fetch(API_URL + "/v1/ems/geteventstype", {
                method: "GET"
            }
        ).then((res) => {
            return res.json();
        }).then((resp) => {
            setEventsType(resp.content)
        }).catch((err) => {
            toast.error('Failed to get data :' + err.message);
        });
    }, [])

    return (
        <div>
            <div className="jumbotron" style={{marginTop: '50px'}}>
                <h1 className="display-4" style={{fontWeight: 'bold', color: "white"}}>Find Your Event</h1>
                <p style={{fontWeight: 'bold'}} className="lead">The homepage of our event management system website is
                    designed to welcome you to
                    the world of seamless event planning and organization. At the top, you'll find our company logo, a
                    symbol of our commitment to quality. Our intuitive navigation menu ensures you can easily explore
                    key sections, from upcoming events to our range of services and client testimonials. Discover what
                    sets us apart in our "About Us" section and stay updated with our latest news and blog posts.
                    Contact us with ease through the provided contact information and stay connected by following us on
                    social media. We're here to make your event management experience exceptional, and our homepage is
                    just the beginning of an exciting journey with us.</p>
                <hr className="my-4"/>
                <p> Welcome!</p>
                <div className="lead">
                    <div className="card text-center offset-lg-2 col-lg-8">
                        <select className="form-control transparent" style={{ opacity: 0.7}} value={selectedOption} onChange={handleChange}>
                            <option value="">Select an option</option>
                            {eventsType.map((eventsType) => (
                                <option key={eventsType.eventTypeId} value={eventsType.eventTypeId}>
                                    {eventsType.eventType}
                                </option>
                            ))}
                        </select>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default EventsType
