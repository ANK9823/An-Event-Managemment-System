import React, {useState, useEffect} from 'react';
import {toast} from "react-toastify";
import {useNavigate} from "react-router-dom";

const EventUpdate = () => {

    const navigate = useNavigate()

    const [updatedEvent, setUpdatedEvent] = useState({
        id: '', // The ID of the event you want to update
        eventName: '',
        description: '',
        eventLocation: '',
    });

    useEffect(() => {

        // fetch(API_URL + "/v1/ems/getAllEventByPlannerId/" + userId, {
        //     method: "GET"
        // }).then((res) => {
        //     return res.json();
        // }).then((resp) => {
        //     setRecords(resp.content)
        // }).catch((err) => {
        //     toast.error('Failed to get data :' + err.message);
        // });

    }, []);


    const handleUpdateEvent = () => {

        fetch(`http://localhost:8086/v1/ems/updateEvent/${updatedEvent.id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(updatedEvent),
        })
            .then((res) => {
                if (res.status === 200) {
                    // Event updated successfully, you may want to show a success message.
                    console.log('Event updated successfully');
                    navigate('/planerEvent');
                } else {
                    // Handle errors if needed.
                    console.error('Failed to update the event');
                }
            })
            .catch((error) => {
                console.error('Failed to update the event: ' + error.message);
            });
    };

    return (
        <div>
            <h2>Update Event</h2>
            <form>
                <div>
                    <label>Event Name:</label>
                    <input
                        type="text"
                        value={updatedEvent.eventName}
                        onChange={(e) => setUpdatedEvent({...updatedEvent, eventName: e.target.value})}
                    />
                </div>
                <div>
                    <label>Description:</label>
                    <textarea
                        value={updatedEvent.description}
                        onChange={(e) => setUpdatedEvent({...updatedEvent, description: e.target.value})}
                    />
                </div>
                <div>
                    <label>Event Location:</label>
                    <input
                        type="text"
                        value={updatedEvent.eventLocation}
                        onChange={(e) => setUpdatedEvent({...updatedEvent, eventLocation: e.target.value})}
                    />
                </div>
                <button onClick={handleUpdateEvent}>Update</button>
            </form>
        </div>
    );
};

export default EventUpdate;
