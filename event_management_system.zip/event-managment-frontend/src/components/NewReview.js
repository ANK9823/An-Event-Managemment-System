import {Link, useNavigate, useParams} from "react-router-dom";
import {useEffect, useState} from "react";
import {toast} from "react-toastify";
import Header from "./Header";
import {API_URL} from "../App";

const NewReview = () => {

    const navigate = useNavigate()
    const [selectedOption, setSelectedOption] = useState("");
    const [Review, ReviewChanged] = useState("");
    const {eventId, eventTypeId} = useParams();

    let userId = sessionStorage.getItem("userId")

    const handleChange = (event) => {
        setSelectedOption(event.target.value)
    };


    const validate = () => {
        let result = true;
        if (selectedOption === '' || selectedOption === null) {
            result = false;
            toast.warning('Please Select Rate');
        }
        if (Review === '' || Review === null) {
            result = false;
            toast.warning('Please Enter Review');
        }

        return result;
    }

    const handlesubmit = (e) => {
        e.preventDefault();
        if (validate()) {
            let regObj = {
                eventId: eventId,
                clientId: userId,
                rating: selectedOption,
                reviewText: Review,
            }
            console.log(regObj)
            fetch(API_URL + "/v1/ems/addreview", {
                method: "POST",
                headers: {'content-type': 'application/json'},
                body: JSON.stringify(regObj)
            }).then(res => {
                return res.json();
            }).then((resp) => {
                if (resp.responseCode !== "200 OK") {
                    toast.error(resp.responseMsg);
                } else {
                    toast.success('Your review has added successfully.')
                    navigate('/events/' + eventTypeId);
                }

            }).catch((err) => {
                toast.error('Failed :' + err.message);
            });
        }
    }

    return (<div>
        <Header/>
        <div className="row">
            <div className="offset-lg-3 col-lg-6" style={{marginTop: '100px'}}>
                <form className="container" onSubmit={handlesubmit}>
                    <div className="card">
                        <div className="card-header">
                            <h1>Add your review</h1>
                        </div>
                        <div className="card-body">
                            <div className="row">
                                <div className="col" style={{marginTop: '10px'}}>
                                    <select className="form-control" value={selectedOption} onChange={handleChange}>
                                        <option value="">Rate</option>
                                        <option key="1" value="1">1</option>
                                        <option key="2" value="2">2</option>
                                        <option key="3" value="3">3</option>
                                        <option key="4" value="4">4</option>
                                        <option key="5" value="5">5</option>
                                    </select>
                                </div>
                            </div>
                            <div className="row" style={{marginTop: '10px'}}>
                                <div className="col">
                                    <textarea value={Review} onChange={e => ReviewChanged(e.target.value)}
                                              type="text" className="form-control" placeholder="Review"/>
                                </div>
                            </div>
                            <div className="card-footer" style={{marginTop: '10px'}}>
                                <button type="submit" className="btn btn-primary">ADD</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>)

}

export default NewReview;
