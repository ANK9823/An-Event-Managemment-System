import {useEffect, useState} from "react";
import {Link, useNavigate} from "react-router-dom";
import {toast} from "react-toastify";
import {API_URL} from "../App";

const Login = () => {
    const [email, emailupdate] = useState('');
    const [password, passwordupdate] = useState('');

    const usenavigate = useNavigate();

    useEffect(() => {
        sessionStorage.clear();
    }, []);

    const ProceedLogin = (e) => {
        e.preventDefault();
        if (validate()) {
            const data = {
                email: email,
                password: password,
            };
            fetch(API_URL + "/v1/ems/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(data),
            }).then((res) => {
                return res.json();
            }).then((resp) => {
                if (resp.responseCode !== "200 OK") {
                    toast.error('Please Enter valid Email or Password');
                } else {
                    toast.success('Success');
                    sessionStorage.setItem('username',resp.content.username);
                    sessionStorage.setItem('userId', resp.content.userId);
                    sessionStorage.setItem('userrole', resp.content.roleId);
                    usenavigate('/home')
                }
            }).catch((err) => {
                toast.error('Login Failed due to :' + err.message);
            });
        }
    }

    const validate = () => {
        let result = true;
        if (email === '' || email === null) {
            result = false;
            toast.warning('Please Enter Email');
        }
        if (password === '' || password === null) {
            result = false;
            toast.warning('Please Enter Password');
        }
        return result;
    }
    return (
        <div>
            <div className="row">
                <div className="offset-lg-3 col-lg-6" style={{marginTop: '100px',opacity: 0.8}}>
                    <form onSubmit={ProceedLogin} className="container">
                        <div className="card">
                            <div className="card-header">
                                <h2>Login</h2>
                            </div>
                            <div className="card-body">
                                <div className="form-group">
                                    <label>Email <span className="errmsg">*</span></label>
                                    <input value={email} onChange={e => emailupdate(e.target.value)}
                                           className="form-control"></input>
                                </div>
                                <div className="form-group">
                                    <label>Password <span className="errmsg">*</span></label>
                                    <input type="password" value={password}
                                           onChange={e => passwordupdate(e.target.value)}
                                           className="form-control"></input>
                                </div>
                            </div>
                            <div className="card-footer">
                                <button type="submit" className="btn btn-primary">Login</button>
                                |
                                <Link className="btn btn-success" to={'/signup/2'}>Signup</Link>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default Login;
