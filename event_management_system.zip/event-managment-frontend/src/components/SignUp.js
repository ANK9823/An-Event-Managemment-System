import {Link, useNavigate, useParams} from "react-router-dom";
import {useState} from "react";
import {toast} from "react-toastify";
import Container from "react-bootstrap/Container";
import Navbar from "react-bootstrap/Navbar";
import {API_URL} from "../App";

const SignUp = () => {

    const {id} = useParams();

    const [username, usernameChanged] = useState("");
    const [password, passwordChanged] = useState("");
    const [email, emailChanged] = useState("");
    const [phone, phoneChanged] = useState("");
    const [roleId, roleIdChanged] = useState(id);

    const navigate = useNavigate()

    let roleType;
    let headerType;
    let headerTypeid;

    if (roleId === "3") {
        roleType = "User registration"
        headerType = "Planer registration"
        headerTypeid = "2"
    } else if (roleId === "2") {
        roleType = "Planer registration"
        headerType = "User registration"
        headerTypeid = "3"
    } else {
        roleType = "Unknown role";
    }

    const validateSignUp = () => {
        let result = true;
        if (email === '' || email === null) {
            result = false;
            toast.warning('Please Enter Email');
        }
        if (password === '' || password === null) {
            result = false;
            toast.warning('Please Enter Password');
        }
        if (username === '' || username === null) {
            result = false;
            toast.warning('Please Enter Username');
        }
        if (phone === '' || phone === null) {
            result = false;
            toast.warning('Please Enter Phone');
        }

        return result;
    }

    const handlesubmit = (e) => {
        e.preventDefault();
        if (validateSignUp()) {
            let regObj = {username: username, password: password, email: email, phone: phone, roleId: id}
            // console.log(regObj)
            fetch(API_URL + "/v1/ems/signup", {
                method: "POST",
                headers: {'content-type': 'application/json'},
                body: JSON.stringify(regObj)
            }).then(res => {
                return res.json();
            }).then((resp) => {
                if (resp.responseCode !== "200 OK") {
                    toast.error(resp.responseMsg);
                } else {
                    toast.success('Registered successfully.')
                    navigate('/login');
                }

            }).catch((err) => {
                toast.error('Failed :' + err.message);
            });
        }
    }

    return (
        <div>
            <Navbar className="bg-body-tertiary" style={{ opacity: 0.7}}>
                <Container>
                    <Navbar.Brand></Navbar.Brand>
                    <Navbar.Toggle/>
                    <Navbar.Collapse className="justify-content-end">
                        <Navbar.Text>
                        </Navbar.Text>
                    </Navbar.Collapse>
                </Container>
                <Navbar.Brand href={`/signup/${headerTypeid}`}>{roleType}</Navbar.Brand>
            </Navbar>
            <div className="row">
                <div className="offset-lg-3 col-lg-6" style={{marginTop: '100px' ,opacity: 0.8}}>
                    <form className="container" onSubmit={handlesubmit}>
                        <div className="card">
                            <div className="card-header">
                                <h1>{headerType}</h1>
                            </div>
                            <div className="card-body">
                                <div className="row">
                                    <div className="col-lg-6">
                                        <div className="form-group">
                                            <label>username<span className="errmsg">*</span></label>
                                            <input value={username} onChange={e => usernameChanged(e.target.value)}
                                                   className="form-control"></input>
                                        </div>
                                    </div>
                                    <div className="col-lg-6">
                                        <div className="form-group">
                                            <label>password<span className="errmsg">*</span></label>
                                            <input value={password} onChange={e => passwordChanged(e.target.value)}
                                                   type="password" className="form-control"></input>
                                        </div>
                                    </div>
                                    <div className="col-lg-6">
                                        <div className="form-group">
                                            <label>email<span className="errmsg">*</span></label>
                                            <input value={email} onChange={e => emailChanged(e.target.value)}
                                                   className="form-control"></input>
                                        </div>
                                    </div>
                                    <div className="col-lg-6">
                                        <div className="form-group">
                                            <label>phone<span className="errmsg">*</span></label>
                                            <input value={phone} onChange={e => phoneChanged(e.target.value)}
                                                   className="form-control"></input>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div className="card-footer">
                                <button type="submit" className="btn btn-primary">Register</button>
                                |
                                <Link to={'/login'} className="btn btn-danger">Close</Link>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    )
}

export default SignUp;
