import {Link, useNavigate} from "react-router-dom";
import {useEffect, useState} from "react";
import TextLinkExample from "./Header";
import Events from "./Events";
import EventsType from "./EventType";
import {toast} from "react-toastify";
import Slider from "react-slick";
import {API_URL} from "../App";

const PlanerEvent = () => {

    const navigate = useNavigate()
    const [records, setRecords] = useState([]);
    const [itemIdToDelete, setItemIdToDelete] = useState(null);

    useEffect(() => {
        let userId = sessionStorage.getItem("userId")

        if (userId === "" || userId === null) {
            navigate("/login")
        } else {
            getData(userId)
            const refreshInterval = setInterval(() => {
                getData(userId)
            }, 5000); // 5000 milliseconds (5 seconds)
            return () => {
                clearInterval(refreshInterval);
            };

        }
    }, []);

    function getData(userId){
        fetch(API_URL + "/v1/ems/getAllEventByPlannerId/" + userId, {
            method: "GET"
        }).then((res) => {
            return res.json();
        }).then((resp) => {
            setRecords(resp.content)
        }).catch((err) => {
            toast.error('Failed to get data :' + err.message);
        });
    }


    function handleGoogleSearch(eventLocation) {
        return undefined;
    }


    function handleDeleteEvent(eventId) {

        console.log(eventId)
        if (window.confirm("Are you sure you want to delete this event?")) {
            fetch(`http://localhost:8086/v1/ems/deleteEvent/${eventId}`, {
                method: "DELETE",
            })
                .then((res) => {
                    if (res.status === 200) {
                        const updatedRecords = records.filter((record) => record.entity.eventId !== eventId);
                        setRecords(updatedRecords);
                        toast.success('Event deleted successfully');
                        navigate('/planerEvent');
                    } else {
                        toast.error('Failed to delete the event.');
                    }
                })
                .catch((err) => {
                    toast.error('Failed to delete the event: ' + err.message);
                });
        }
    }

    const sliderSettings = {
        dots: true, // Show dots for navigation
        infinite: true, // Infinite loop
        speed: 500, // Transition speed
        slidesToShow: 1, // Number of slides to show at a time
        slidesToScroll: 1, // Number of slides to scroll
    };


    return (<div>
        <TextLinkExample/>
        <h1 style={{color:"white"}}>My Events</h1>
        <div className="d-grid gap-2 col-3 mx-auto" style={{marginTop: '10px'}}>
            <Link to={'/newEvents'} className="btn btn-outline-light">+ New</Link>
        </div>
        <div className="row">
            {records.map((list, index) => (
                <div className="card text-center offset-lg-2 col-lg-8" style={{marginTop: '10px'}}>
                    <div className="card-header text-end " style={{color: 'blue'}}>
                        Event type - {list.eventType}
                    </div>
                    <div className="card-body">
                        <h5 className="card-title">{list.entity.eventName} </h5>
                        <p className="card-text" style={{color: 'gray'}}>{list.entity.description} </p>
                        <div>
                            <Slider {...sliderSettings}>
                                {list.images.map((image, imageIndex) => (
                                    <div key={imageIndex} className="align-content-center">
                                        <img
                                            src={`data:image/png;base64,${image}`}
                                            width="500"
                                            alt="Image"
                                            style={{
                                                display: "block",
                                                margin: "0 auto",
                                            }}
                                        />
                                    </div>
                                ))}
                            </Slider>
                        </div>
                        <div style={{marginTop: "30px"}}>
                            <p> Location - <a
                                onClick={handleGoogleSearch(list.entity.eventLocation)}>{list.entity.eventLocation}</a>
                            </p>
                            <form>
                                {/*<Link to={`/updateEvent/${list.entity.eventId}`} className="btn btn-outline-primary">Update*/}
                                {/*</Link>*/}
                                {/*|*/}
                                <button className="btn btn-outline-danger"
                                        onClick={() => handleDeleteEvent(list.entity.eventId)}>Delete</button>
                            </form>
                        </div>
                    </div>
                    <div className="card-footer text-muted">
                        posted on : {list.entity.eventCreatedDate}
                    </div>
                </div>))}
        </div>
    </div>)
}

export default PlanerEvent;
