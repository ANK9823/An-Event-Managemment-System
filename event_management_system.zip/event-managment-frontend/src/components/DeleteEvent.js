import {Link, useNavigate, useParams} from "react-router-dom";
import {useEffect, useState} from "react";
import {toast} from "react-toastify";
import {API_URL} from "../App";


const DeleteEvent = () => {

    const navigate = useNavigate()
    const [records, setRecords] = useState([]);
    const {id} = useParams();

    useEffect(() => {

        fetch(API_URL + "/v1/ems/deleteEvent/" + id, {
            method: "DELETE",
        }).then(res => {
            return res.json();
        }).then((resp) => {
            if (resp.responseCode !== "200 OK") {
                toast.error(resp.responseMsg);
            } else {
                navigate("/planerEvent")
                toast.success('Deleted.')
            }

        }).catch((err) => {
            toast.error('Failed :' + err.message);
        });

    }, [])

}

export default DeleteEvent;
