import {Link, useNavigate} from "react-router-dom";
import {useEffect} from "react";
import TextLinkExample from "./Header";
import Events from "./Events";
import EventsType from "./EventType";

const Index = () => {
    useEffect(() => {

        sessionStorage.clear();

    }, []);

    return (
        <div>
            <div className="jumbotron" style={{marginTop: '50px'}}>
                <h1 className="display-4" style={{fontWeight: 'bold', color: "white"}}>Find Your Event</h1>
                <p style={{fontWeight: 'bold'}} className="lead">The homepage of our event management system website is designed to welcome you to
                    the world of seamless event planning and organization. At the top, you'll find our company logo, a
                    symbol of our commitment to quality. Our intuitive navigation menu ensures you can easily explore
                    key sections, from upcoming events to our range of services and client testimonials. Discover what
                    sets us apart in our "About Us" section and stay updated with our latest news and blog posts.
                    Contact us with ease through the provided contact information and stay connected by following us on
                    social media. We're here to make your event management experience exceptional, and our homepage is
                    just the beginning of an exciting journey with us.</p>
                <hr className="my-4"/>
                <p> Welcome!</p>
                <form>
                    <Link to={`/login`} className="btn btn-success" style={{width: '300px'}}>Sign in</Link>
                </form>
            </div>
        </div>
    )
}

export default Index;
