import Container from 'react-bootstrap/Container';
import Navbar from 'react-bootstrap/Navbar';
import {useEffect, useState} from "react";

const Header = () => {

    const [sessionValue, setSessionValue] = useState('');

    useEffect(() => {
        const storedSessionValue = sessionStorage.getItem('username');
        setSessionValue(storedSessionValue);
    }, []);

    return (
        <Navbar className="bg-body-tertiary" style={{ opacity: 0.7}}>
            <Container>
                <Navbar.Brand href="/home">Home</Navbar.Brand>
                <Navbar.Toggle/>
                <Navbar.Collapse className="justify-content-end">
                    <Navbar.Text>
                        Signed in as: <a href="#login">{sessionValue}</a>
                    </Navbar.Text>
                </Navbar.Collapse>
            </Container>
            <Navbar.Brand href="/">Logout</Navbar.Brand>
            <Navbar.Toggle/>
        </Navbar>
    );
}

export default Header;
