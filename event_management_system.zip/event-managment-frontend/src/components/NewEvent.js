import {Link, useNavigate, useParams} from "react-router-dom";
import {useEffect, useState} from "react";
import {toast} from "react-toastify";
import {useDropzone} from "react-dropzone";
import {API_URL} from "../App";

const NewEvents = () => {

    const navigate = useNavigate()
    const [eventsType, setEventsType] = useState([]);
    const [selectedOption, setSelectedOption] = useState("");
    const [eventId, setEventId] = useState("");

    const [eventName, eventNameChanged] = useState("");
    const [eventLocation, eventLocationChanged] = useState("");
    const [description, descriptionChanged] = useState("");

    let userId = sessionStorage.getItem("userId")

    const [selectedFiles, setSelectedFiles] = useState([]);


    const onDrop = (acceptedFiles) => {
        setSelectedFiles(acceptedFiles);
    };

    const { getRootProps, getInputProps } = useDropzone({
        onDrop,
        accept: "image/*", // Allow only image files
        multiple: true, // Allow multiple file selection
    });
    const handleChange = (event) => {
        setSelectedOption(event.target.value)
    };

    useEffect(() => {

        fetch(API_URL + "/v1/ems/geteventstype", {
                method: "GET"
            }
        ).then((res) => {
            return res.json();
        }).then((resp) => {
            setEventsType(resp.content)
        }).catch((err) => {
            toast.error('Failed to get data :' + err.message);
        });


    }, [])

    const validate = () => {
        let result = true;
        if (selectedFiles === [] || selectedFiles === null) {
            result = false;
            toast.warning('Upload Image');
        }
        if (selectedOption === '' || selectedOption === null) {
            result = false;
            toast.warning('Please Enter Email');
        }
        if (eventName === '' || eventName === null) {
            result = false;
            toast.warning('Please Enter eventName');
        }
        if (eventLocation === '' || eventLocation === null) {
            result = false;
            toast.warning('Please Enter eventLocation');
        }
        if (description === '' || description === null) {
            result = false;
            toast.warning('Please Enter description');
        }

        return result;
    }

    const handlesubmit = (e) => {
        e.preventDefault();

        const formData = new FormData();
        selectedFiles.forEach((file) => {
            formData.append("images", file);
        });
        formData.append("userId", userId);

        if (validate()) {
            let regObj = {
                eventTypeId: selectedOption,
                eventName: eventName,
                eventLocation: eventLocation,
                description: description,
                plannerId: userId
            }
            console.log(regObj)
            fetch(API_URL + "/v1/ems/createnewevent", {
                method: "POST",
                headers: {'content-type': 'application/json'},
                body: JSON.stringify(regObj)
            }).then(res => {
                return res.json();
            }).then((resp) => {
                if (resp.responseCode !== "200 OK") {
                    toast.error(resp.responseMsg);
                } else {
                    formData.append("eventId", resp.content);
                    toast.success('event has added successfully.')

                    if (selectedFiles.length > 0){
                        fetch(API_URL + "/v1/ems/uploadImages", {
                            method: "POST",
                            body: formData,
                        }).then(res => {
                            return res.json();
                        }).then((resp) => {
                            if (resp.responseCode !== "200 OK") {
                                toast.error(resp.responseMsg);
                            }else{
                                navigate('/planerEvent');
                            }
                        }).catch((err) => {
                            toast.error('Failed :' + err.message);
                        });
                    }
                    navigate('/planerEvent');
                }

            }).catch((err) => {
                toast.error('Failed :' + err.message);
            });
        }
    }

    return (<div>
        <div className="row">
            <div className="offset-lg-3 col-lg-6" style={{marginTop: '100px', opacity: 0.7}}>
                <form className="container" onSubmit={handlesubmit}>
                    <div className="card">
                        <div className="card-header">
                            <h1>Create New</h1>
                        </div>
                        <div className="card-body">
                            <div className="row">
                                <div className="col" style={{marginTop: '10px'}}>
                                    <select className="form-control" value={selectedOption} onChange={handleChange}>
                                        <option value="">Select an event</option>
                                        {eventsType.map((eventsType) => (
                                            <option key={eventsType.eventTypeId} value={eventsType.eventTypeId}>
                                                {eventsType.eventType}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                            </div>
                            <div className="row" style={{marginTop: '10px'}}>
                                <div className="col">
                                    <input value={eventName} onChange={e => eventNameChanged(e.target.value)}
                                           type="text"
                                           className="form-control" placeholder="Event Name"/>
                                </div>
                            </div>
                            <div className="row" style={{marginTop: '10px'}}>
                                <div className="col">
                                    <input value={eventLocation} onChange={e => eventLocationChanged(e.target.value)}
                                           type="text"
                                           className="form-control" placeholder="Event Location"/>
                                </div>
                            </div>
                            <div className="row" style={{marginTop: '10px'}}>
                                <div className="col">
                                    <textarea value={description} onChange={e => descriptionChanged(e.target.value)}
                                              type="text" className="form-control" placeholder="Description"/>
                                </div>
                            </div>
                            {/* Other form fields */}
                            <div className="row" style={{ marginTop: "10px" }}>
                                <div className="col" {...getRootProps()}>
                                    <input {...getInputProps()} />
                                    <p>Drag 'n' drop some files here, or click to select files</p>
                                </div>
                            </div>
                            {/* Other form fields */}
                            <div className="card-footer" style={{marginTop: '10px'}}>
                                <button type="submit" className="btn btn-primary">ADD</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>)

}

export default NewEvents;
