import {useNavigate} from "react-router-dom";
import {useEffect} from "react";
import EventsType from "./EventType";
import Header from "./Header";
import '../App.css'

const Home = () => {

    const navigate = useNavigate()

    let  backgroundImage = ""

    const componentStyle = {
        backgroundImage: `url("src/images/img1.jpg")`,
        backgroundSize: 'cover', // Adjust as needed
    };


    useEffect(() => {
        let userId = sessionStorage.getItem("userId")
        let userRoleId = sessionStorage.getItem("userrole")
        if (userId === "" || userId === null) {
            navigate("/login")
        } else if (userRoleId === "3") {
            navigate("/planerEvent")
        }
    }, []);


    return (
        <div style={componentStyle}>
            <Header/>
            <EventsType/>
        </div>
    )
}

export default Home;
