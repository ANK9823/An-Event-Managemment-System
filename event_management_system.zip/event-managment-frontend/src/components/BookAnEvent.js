import {useNavigate, useParams} from "react-router-dom";
import {useEffect, useState} from "react";
import {toast} from "react-toastify";
import Header from "./Header";
import {API_URL} from "../App";


const BookAnEvents = () => {

    const navigate = useNavigate()
    const [receiver, setReceiver] = useState("");
    const {id, name, plannerId} = useParams();

    const [Email, EmailChanged] = useState("");
    const [Phone, PhoneChanged] = useState("");
    const [Remark, RemarkChanged] = useState("");

    useEffect(() => {
        fetch(API_URL + "/v1/ems/getuserdata/" + plannerId, {
                method: "GET"
            }
        ).then((res) => {
            return res.json();
        }).then((resp) => {
            setReceiver(resp.content.email)
        }).catch((err) => {
            toast.error('Failed to get data :' + err.message);
        });
    }, [])

    const validate = () => {
        let result = true;
        if (Email === '' || Email === null) {
            result = false;
            toast.warning('Please Enter Email');
        }
        if (Phone === '' || Phone === null) {
            result = false;
            toast.warning('Please Enter Phone');
        }
        return result;
    }

    const handlesubmit = (e) => {
        e.preventDefault();
        if (validate()) {
            let body = "your event " + name + " [" + id + "] has booked. please contact phone : " + Phone + " email : " + Email + "" +
                "remark - " + Remark

            let regObj = {
                receiver: receiver,
                body: body
            }

            fetch(API_URL + "/v1/ems/sendmail", {
                    method: "POST",
                    headers: {'content-type': 'application/json'},
                    body: JSON.stringify(regObj)
                }
            ).then((res) => {
                return res.json();
            }).then((resp) => {
                if (resp.responseCode !== "200 OK") {
                    toast.error(resp.responseMsg);
                } else {
                    toast.success('Sent mail to Planner successfully.')
                    navigate('/home');
                }
            }).catch((err) => {
                toast.error('Failed to get data :' + err.message);
            });
        }

    }

    return (<div>
        <Header/>
        <div className="offset-lg-3 col-lg-6" style={{marginTop: '100px',opacity: 0.7}}>
            <form className="container" onSubmit={handlesubmit}>
                <div className="card">
                    <div className="card-header">
                        <h1>Book Now</h1>
                    </div>
                    <div className="card-body">
                        <div className="row" style={{marginTop: '10px'}}>
                            <div className="col">
                                <input value={Email} onChange={e => EmailChanged(e.target.value)}
                                       type="text"
                                       className="form-control" placeholder="Email"/>
                            </div>
                        </div>
                        <div className="row" style={{marginTop: '10px'}}>
                            <div className="col">
                                <input value={Phone} onChange={e => PhoneChanged(e.target.value)}
                                       type="text"
                                       className="form-control" placeholder="Phone"/>
                            </div>
                        </div>
                        <div className="row" style={{marginTop: '10px'}}>
                            <div className="col">
                                    <textarea value={Remark} onChange={e => RemarkChanged(e.target.value)}
                                              type="text" className="form-control" placeholder="Remark"/>
                            </div>
                        </div>
                        <div className="card-footer" style={{marginTop: '10px'}}>
                            <button type="submit" className="btn btn-primary">APPLY</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>)

}

export default BookAnEvents;
